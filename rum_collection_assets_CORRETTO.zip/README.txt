RUM COLLECTION — RITAGLI CORRETTI

Questa versione sostituisce il precedente archivio ZIP.
Sono inclusi 24 ritagli (6 per schermata), ciascuno con l'intera scheda visibile:
bottiglia/confezione e didascalia sottostante.

NOTA: gli screenshot sono schermate scorrevoli e alcune righe si ripetono tra schermate
consecutive. Questa selezione prende le due righe centrali di ciascuna schermata;
prima di pubblicare definitivamente il catalogo, controllare i nomi e gli eventuali
doppioni residui. I ritagli mantengono la qualità degli screenshot originali.

Caricamento:
- Estrai lo ZIP sul dispositivo.
- Carica la cartella images dentro assets/ del progetto GitHub.
- Carica catalogo_immagini.csv nella cartella assets/.
Non caricare lo ZIP come se fosse una cartella di immagini: va prima estratto.
