RUM COLLECTION — IMMAGINI PER IL PROGETTO

Contenuto
- images/: 24 ritagli JPEG ricavati dalle quattro schermate fornite.
- catalogo_immagini.csv: indice dei ritagli e screenshot di origine.

IMPORTANTE
I ritagli conservano la porzione della schermata con bottiglia/confezione e la relativa etichetta quando visibile.
Le schermate si sovrappongono nello scorrimento: prima di pubblicare il catalogo definitivo, controllare eventuali doppioni
e completare i nomi delle bottiglie. I ritagli sono immagini di lavoro, non fotografie originali ad alta risoluzione.

Dove caricare su GitHub
1. Apri la repository del progetto Rum Collection.
2. Crea una cartella chiamata assets.
3. Dentro assets crea una cartella chiamata images.
4. Carica in images tutti i 24 file .jpg.
5. Carica catalogo_immagini.csv nella cartella principale oppure dentro assets.

Struttura finale consigliata:
assets/
  images/
    rum_01.jpg
    ...
    rum_24.jpg
  catalogo_immagini.csv
